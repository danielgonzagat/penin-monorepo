# Lemniscata de Penin — pacote núcleo
__all__ = ["core", "integrity", "scaling", "audit", "version"]
__version__ = "1.0.0"
