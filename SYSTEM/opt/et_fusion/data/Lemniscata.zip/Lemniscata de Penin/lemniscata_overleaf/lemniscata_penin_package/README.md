# Lemniscata de Penin (infty-bar) — Pacote Núcleo

Conteúdo:
- pacote `lemniscata/` (core, integridade, scaling, audit, tests);
- `docs/` (provas, API, arquitetura, benchmarks, símbolo, DoD);
- `outputs/` (logs e plots).

Núcleo imutável; normalize E/N; padronize I.
