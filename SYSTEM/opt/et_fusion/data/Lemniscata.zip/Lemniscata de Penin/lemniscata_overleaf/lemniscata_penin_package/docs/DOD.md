# Definition of Done (DoD)

- Teoria: provas (redução, limites, monotonicidade, idempotência, projeção).
- Engenharia: pacote com API estável, testes de invariantes, logger.
- Validação: benchmarks (LLM/RL/MA) com gráficos e tabelas (parcial/total vs baseline).
- Arquitetura: guia plugável (Q/MA/BioIA) sem tocar no núcleo.
- Padrão & Comunicação: símbolo, macro LaTeX, alias e checklist.
